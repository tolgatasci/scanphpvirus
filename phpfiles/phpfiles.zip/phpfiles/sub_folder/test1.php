<?php


base64_decode("xxxxxxxxxxx");