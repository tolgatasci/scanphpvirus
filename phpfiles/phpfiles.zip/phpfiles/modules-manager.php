<?php 

$x = 1;

$update = "update users set password='xxxx' where id = 1";