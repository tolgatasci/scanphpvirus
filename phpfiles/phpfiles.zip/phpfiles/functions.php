<?php

$query = "insert into users (username,password) values ('admin','admin')";