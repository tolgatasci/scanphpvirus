<?php
		$sql = "update ".$DB."_prefix set x = 1 where id = 1";
		
		file_put_contents("x.php","<?php ?>");