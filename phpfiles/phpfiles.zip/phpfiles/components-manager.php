<?php
$xxxxxxxxx = 1;

$test = "xx";